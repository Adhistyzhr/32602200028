package Tictactoe;
    // GameBoard.java
public class GameBoard {
    private String[][] board;

    public GameBoard() {
        // Inisialisasi papan permainan
        board = new String[3][3];
        // Mengisi papan dengan nilai awal
        // ...
    }

    public String getValue(int row, int col) {
        return board[row][col];
    }

    public void setValue(int row, int col, String value) {
        board[row][col] = value;
    }
}