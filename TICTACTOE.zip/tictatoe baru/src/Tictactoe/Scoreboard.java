package Tictactoe;
    // Scoreboard.java
    public class Scoreboard {
    private int xCount;
    private int oCount;

    public int getXCount() {
        return xCount;
    }

    public void setXCount(int xCount) {
        this.xCount = xCount;
    }

    public int getOCount() {
        return oCount;
    }

    public void setOCount(int oCount) {
        this.oCount = oCount;
    }
}
