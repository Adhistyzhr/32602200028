package Tictactoe;
public interface GameFeatures {
    // GameFeatures.java
    void choosePlayer();
    void gameScore();
    void winningGame();
    void resetGame();
    void exitGame();
}