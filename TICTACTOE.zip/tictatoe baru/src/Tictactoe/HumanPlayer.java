package Tictactoe;
    // HumanPlayer.java
public class HumanPlayer extends Player {
    public HumanPlayer(String symbol) {
        super(symbol);
    }
}